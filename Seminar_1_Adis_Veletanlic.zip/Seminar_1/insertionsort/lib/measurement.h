#ifndef MEASUREMENT_HEADER
#define MEASUREMENT_HEADER

void measure_insertionsort(long *arr, long *COLLECTION_SIZE);

#endif