#ifndef INSERTION_SORT_HEADER
#define INSERTION_SORT_HEADER

void insertionsort(long *arr, long size);

#endif