# Seminar 1

## Usage

To run any of the algorithms:

- cd into the desired directory (/binarysearch, /quicksort, /insertionsort)
- run ```make build; make test; ./bin/main```