#ifndef BINARY_SEARCH_HEADER
#define BINARY_SEARCH_HEADER

int binarysearch(long *arr, long low, long high, long find);

#endif