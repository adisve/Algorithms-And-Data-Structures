#ifndef MEASUREMENT_HEADER
#define MEASUREMENT_HEADER

void measure_binarysearch(long *arr, long *COLLECTION_SIZE);

#endif