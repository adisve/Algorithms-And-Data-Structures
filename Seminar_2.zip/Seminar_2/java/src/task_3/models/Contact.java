package task_3.models;

public class Contact {

    public String name;
    public String address;

    public Contact(String name, String address)
    {
        this.name = name;
        this.address = address;
    }
}
