package task_2;

public class Main {
    
    public static void main(String[] args) {
        Test test = new Test();
        test.testTwoStackQueue();
        test.testOneStackQueue();
        test.testTwoQueueStack();
        test.testOneQueueStack();
    }
}