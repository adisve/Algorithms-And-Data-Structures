javac --source-path src -d bin src/task_2/*.java
javac --source-path src -d bin src/task_3/*.java
javac --source-path src -d bin src/task_4/*.java